import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("data/sales_data.csv")

# Create Total Sales column
df["Total Sales"] = df["Quantity"] * df["Price"]

print("\nDataset Preview\n")
print(df.head())

# Total Revenue
total_revenue = df["Total Sales"].sum()
print(f"\nTotal Revenue: ₹{total_revenue:,}")

# Category-wise Sales
category_sales = df.groupby("Category")["Total Sales"].sum()

# Top Products
top_products = (
    df.groupby("Product")["Total Sales"]
    .sum()
    .sort_values(ascending=False)
)

# Monthly Sales
df["Date"] = pd.to_datetime(df["Date"])
df["Month"] = df["Date"].dt.strftime("%b")

monthly_sales = (
    df.groupby("Month")["Total Sales"]
    .sum()
    .reindex(["Jan", "Feb", "Mar", "Apr"])
)

# Plot 1
monthly_sales.plot(kind="bar", figsize=(8,5))
plt.title("Monthly Sales")
plt.ylabel("Revenue")
plt.tight_layout()
plt.savefig("images/monthly_sales.png")
plt.close()

# Plot 2
category_sales.plot(kind="bar", figsize=(8,5))
plt.title("Category-wise Revenue")
plt.ylabel("Revenue")
plt.tight_layout()
plt.savefig("images/category_sales.png")
plt.close()

# Plot 3
top_products.head(5).plot(kind="bar", figsize=(8,5))
plt.title("Top Selling Products")
plt.ylabel("Revenue")
plt.tight_layout()
plt.savefig("images/top_products.png")
plt.close()

print("\nAnalysis Completed Successfully!")
