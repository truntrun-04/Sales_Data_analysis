# 📊 Sales Data Analysis using Python

## Overview

This project analyzes retail sales data using Python. It demonstrates the basic data analysis workflow, including data cleaning, exploration, visualization, and business insight generation.

The goal of this project is to identify sales trends, top-performing products, and category-wise revenue using Python libraries like Pandas, NumPy, and Matplotlib.

---

## Features

- Data Cleaning
- Sales Analysis
- Revenue Calculation
- Category-wise Analysis
- Monthly Sales Trends
- Data Visualization

---

## Technologies Used

- Python
- Pandas
- NumPy
- Matplotlib

---

## Project Structure

```
Sales-Data-Analysis/
│
├── data/
├── images/
├── notebook/
├── src/
├── README.md
├── requirements.txt
└── LICENSE
```

---

## Dataset

The dataset contains:

- Order ID
- Date
- Product
- Category
- Quantity
- Price

---

## Analysis Performed

- Total Revenue
- Monthly Sales
- Category-wise Revenue
- Top Selling Products

---

## Visualizations

### Monthly Sales

![Monthly Sales](images/monthly_sales.png)

---

### Category-wise Revenue

![Category Sales](images/category_sales.png)

---

### Top Selling Products

![Top Products](images/top_products.png)

---

## Business Insights

- Electronics generated the highest revenue.
- Laptop contributed the highest sales.
- Sales increased steadily over the months.
- Fashion products generated moderate revenue.

---

## How to Run

Clone the repository

```bash
git clone https://github.com/yourusername/Sales-Data-Analysis.git
```

Install dependencies

```bash
pip install -r requirements.txt
```

Run

```bash
python src/sales_analysis.py
```

---

## Author

Tarun Tanwar

LinkedIn

https://www.linkedin.com/in/tarun-tanwar04/

GitHub

https://github.com/yourusername
